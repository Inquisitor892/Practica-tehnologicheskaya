
import { useEffect, useState } from "react";
import { PlusCircle, Search } from "lucide-react";

export default function App() {
  const defaultRecipes = [
    {
      title: "Омлет",
      ingredients: "Яйца, Молоко, Соль",
      instructions: "Смешать яйца с молоком и щепоткой соли. Вылить на разогретую сковороду и жарить до готовности.",
      image: ""
    }
  ];

  const [recipes, setRecipes] = useState(() => {
    const stored = localStorage.getItem("recipes");
    return stored ? JSON.parse(stored) : defaultRecipes;
  });

  const [search, setSearch] = useState("");
  const [newRecipe, setNewRecipe] = useState({
    title: "",
    ingredients: "",
    instructions: "",
    image: ""
  });

  useEffect(() => {
    localStorage.setItem("recipes", JSON.stringify(recipes));
  }, [recipes]);

  const filteredRecipes = recipes.filter((r) =>
    r.title.toLowerCase().includes(search.toLowerCase())
  );

  const addRecipe = () => {
    if (newRecipe.title.trim()) {
      setRecipes([...recipes, newRecipe]);
      setNewRecipe({ title: "", ingredients: "", instructions: "", image: "" });
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Кулинарные рецепты</h1>

      <div className="flex items-center gap-2 mb-6">
        <input
          className="border px-2 py-1 rounded w-full"
          placeholder="Поиск по названию..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Search className="text-gray-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredRecipes.map((recipe, index) => (
          <div key={index} className="bg-white shadow rounded-2xl p-4">
            {recipe.image && (
              <img src={recipe.image} alt={recipe.title} className="w-full h-48 object-cover rounded mb-2" />
            )}
            <h2 className="text-xl font-semibold mb-2">{recipe.title}</h2>
            <p className="text-sm text-gray-700 mb-1">
              <strong>Ингредиенты:</strong> {recipe.ingredients}
            </p>
            <p className="text-sm text-gray-700">
              <strong>Инструкция:</strong> {recipe.instructions}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-2">Добавить рецепт</h2>
        <div className="grid gap-3">
          <input
            className="border px-2 py-1 rounded"
            placeholder="Название рецепта"
            value={newRecipe.title}
            onChange={(e) => setNewRecipe({ ...newRecipe, title: e.target.value })}
          />
          <input
            className="border px-2 py-1 rounded"
            placeholder="Ингредиенты (через запятую)"
            value={newRecipe.ingredients}
            onChange={(e) => setNewRecipe({ ...newRecipe, ingredients: e.target.value })}
          />
          <textarea
            className="border px-2 py-1 rounded"
            placeholder="Инструкция приготовления"
            value={newRecipe.instructions}
            onChange={(e) => setNewRecipe({ ...newRecipe, instructions: e.target.value })}
          />
          <input
            className="border px-2 py-1 rounded"
            placeholder="Ссылка на изображение (необязательно)"
            value={newRecipe.image}
            onChange={(e) => setNewRecipe({ ...newRecipe, image: e.target.value })}
          />
          {newRecipe.image && (
            <img
              src={newRecipe.image}
              alt="Предпросмотр"
              className="w-full h-48 object-cover rounded border mb-2"
              onError={(e) => { e.target.style.display = 'none'; }}
            />
          )}
          <button onClick={addRecipe} className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded">
            <PlusCircle /> Добавить рецепт
          </button>
        </div>
      </div>
    </div>
  );
}
